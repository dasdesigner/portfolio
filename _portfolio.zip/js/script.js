
$(document).on('keyup', function (evt) {
  if (evt.keyCode == 27) {
    $(".screen").toggleClass("show");
  }
});
 